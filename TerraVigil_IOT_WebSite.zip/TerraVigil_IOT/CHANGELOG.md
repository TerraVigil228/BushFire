# Change Log

## [1.0.0] 2018-02-16
### Original Release

## [1.0.1] 2018-02-21
### Bugfixing
- Fixed some issues for documentation pages
- Scss cleaned
- Other bug fixes
