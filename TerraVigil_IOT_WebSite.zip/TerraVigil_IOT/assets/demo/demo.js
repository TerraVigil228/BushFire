const demo = {
  loadTemperatureData: function () {
    return fetch('https://script.google.com/macros/s/AKfycbzyLWNEB8bU_8MHgohURb2LFsqn-2K4Zct5O9egpKMmjtGnj_ohJ4c_A7sjw14D9S1vww/exec')
      .then(res => res.json())
      .then(result => {
        const rawData = result.data.map(item => ({
          timestamp: item.timestamp,
          temperature: parseFloat(item.temperature) || 0
        }));
        rawData.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
        const last10 = rawData.slice(0, 10).reverse();

        return {
          labels: last10.map(item => {
            const date = new Date(item.timestamp);
            return date.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
          }),
          values: last10.map(item => item.temperature)
        };
      });
  },

  loadCOData: function () {
    return fetch('https://script.google.com/macros/s/AKfycbzyLWNEB8bU_8MHgohURb2LFsqn-2K4Zct5O9egpKMmjtGnj_ohJ4c_A7sjw14D9S1vww/exec')
      .then(res => res.json())
      .then(result => {
        const rawData = result.data.map(item => ({
          timestamp: item.timestamp,
          co: parseFloat(item.co) || 0
        }));
        rawData.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
        const last10 = rawData.slice(0, 10).reverse();

        return {
          labels: last10.map(item => {
            const date = new Date(item.timestamp);
            return date.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
          }),
          values: last10.map(item => item.co)
        };
      });
  },

  loadFumeData: function () {
    return fetch('https://script.google.com/macros/s/AKfycbzyLWNEB8bU_8MHgohURb2LFsqn-2K4Zct5O9egpKMmjtGnj_ohJ4c_A7sjw14D9S1vww/exec')
      .then(res => res.json())
      .then(result => {
        const rawData = result.data.map(item => ({
          timestamp: item.timestamp,
          fume: parseFloat(item.fume) || 0
        }));
        rawData.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
        const last10 = rawData.slice(0, 10).reverse();

        return {
          labels: last10.map(item => {
            const date = new Date(item.timestamp);
            return date.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
          }),
          values: last10.map(item => item.fume)
        };
      });
  },

  loadHumiditeData: function () {
    return fetch('https://script.google.com/macros/s/AKfycbzyLWNEB8bU_8MHgohURb2LFsqn-2K4Zct5O9egpKMmjtGnj_ohJ4c_A7sjw14D9S1vww/exec')
      .then(res => res.json())
      .then(result => {
        const rawData = result.data.map(item => ({
          timestamp: item.timestamp,
          humidite: parseFloat(item.humidite) || 0
        }));
        rawData.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
        const last10 = rawData.slice(0, 10).reverse();

        return {
          labels: last10.map(item => {
            const date = new Date(item.timestamp);
            return date.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
          }),
          values: last10.map(item => item.humidite)
        };
      });
  },

  createChart: function (elementId, label, color, chartData, type = 'line') {
    const ctx = document.getElementById(elementId).getContext('2d');
    const gradient = ctx.createLinearGradient(0, 170, 0, 50);
    gradient.addColorStop(0, "rgba(128, 182, 244, 0)");
    gradient.addColorStop(1, color);

    return new Chart(ctx, {
      type: type,
      data: {
        labels: chartData.labels,
        datasets: [{
          label: label,
          borderColor: color,
          pointBackgroundColor: color,
          backgroundColor: type === 'line' ? gradient : color,
          fill: type === 'line',
          data: chartData.values
        }]
      },
      options: {
        maintainAspectRatio: false,
        legend: { display: false },
        scales: {
          yAxes: [{
            ticks: {
              fontColor: "#ccc",
              beginAtZero: true
            },
            gridLines: {
              color: "rgba(255,255,255,0.1)"
            }
          }],
          xAxes: [{
            ticks: {
              fontColor: "#ccc",
              maxRotation: 0,
              minRotation: 0
            },
            gridLines: {
              color: "rgba(255,255,255,0.1)"
            }
          }]
        }
      }
    });
  },

  initDashboardPageCharts: function () {
    this.loadTemperatureData().then(data => this.createChart('bigDashboardChart', 'Température (°C)', '#f96332', data));
    this.loadCOData().then(data => this.createChart('lineChartExample', 'CO (ppm)', '#1e3d60', data));
    this.loadFumeData().then(data => this.createChart('lineChartExampleWithNumbersAndGrid', 'Fumée', '#18ce0f', data, 'radar'));
    this.loadHumiditeData().then(data => this.createChart('barChartSimpleGradientsNumbers', 'Humidité (%)', '#51cbce', data, 'bar'));
  }
};

document.addEventListener('DOMContentLoaded', function () {
  demo.initDashboardPageCharts();
});

setInterval(() => {
  demo.loadTemperatureData().then(data => demo.createChart('bigDashboardChart', 'Température (°C)', '#f96332', data));
  demo.loadCOData().then(data => demo.createChart('lineChartExample', 'CO (ppm)', '#1e3d60', data));
  demo.loadFumeData().then(data => demo.createChart('lineChartExampleWithNumbersAndGrid', 'Fumée', '#18ce0f', data, 'radar'));
  demo.loadHumiditeData().then(data => demo.createChart('barChartSimpleGradientsNumbers', 'Humidité (%)', '#51cbce', data, 'bar'));
}, 1000); // ← ici 10 secondes (10 000 ms), ajuste comme tu veux
